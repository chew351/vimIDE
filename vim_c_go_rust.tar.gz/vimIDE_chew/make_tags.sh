#!/bin/bash
# File              : make_tags.sh
# Author            : zcy
# Date              : 2019-03-16 12:16:44
# Last Modified Date: 2021-08-04 19:17:50

#20181111 by chew

CUR_PATH=$(cd "$(dirname "$0")"; pwd)
CTAGS_FILES=${CUR_PATH}/ctags.files
CTAGS_OPTIONS=${CUR_PATH}/ctags.options

DIRS=(
"${CUR_PATH}/foo" \
)

FILES=(
"*.h" \
"*.c" \
"*.cc" \
"*.cpp" \
"*.go" \
"*.rs" \
)


function make_tags() {
    local dirs=($1)
    local files=($2)

    echo "${files[*]} in ${dirs[*]}" 

    ctags_options

    local files_cnt=0
    local lines_cnt=0

    local clean_cmd="rm -f cscope.* && rm -f tags && rm -f ${CTAGS_FILES}"
    local ctags_cmd="ctags --c++-kinds=+p+l+x+c+d+e+f+g+m+n+s+t+u+v --fields=+liazKS --extra=+q --options=${CTAGS_OPTIONS} -L" 
    local cscope_cmd="cscope -bkq -i"

    echo "Updating tags ..."
    rm -f ${CTAGS_FILES}
    for tpath in ${dirs[@]}
    do
        for tfile in ${files[@]}
        do
            #echo "Find ${tfile} from ${tpath}" 
            local all_files=`eval find ${tpath} -name ${tfile} -print -follow | grep -v "mkbuild" | grep -v "build-root/"` #>> ${CTAGS_FILES}
            for ff in ${all_files[@]}
            do
                if [[ -L ${ff} ]]; then
                    readlink -f ${ff} >> ${CTAGS_FILES}
                else
                    echo ${ff} >> ${CTAGS_FILES}
                fi
            done
        done
    done
   
    echo "== ${cscope_cmd} ${CTAGS_FILES} =="
    time ${cscope_cmd} ${CTAGS_FILES}

    echo "== ${ctags_cmd} ${CTAGS_FILES} =="
    time ${ctags_cmd} ${CTAGS_FILES}

    files_cnt=`awk 'END{print NR}' ${CTAGS_FILES}`
    lines_cnt=`awk '{for(i=1;i<=NF;i++){print $i}}' ${CTAGS_FILES} | xargs wc -l | awk 'END{print $1}'`
    echo "${files_cnt} files ${lines_cnt} lines Update complete."
}

function clean_tags() {
    local clean_cmd="rm -f cscope.* && rm -f tags && rm -f ${CTAGS_FILES} ${CTAGS_OPTIONS}"
    echo "=== ${clean_cmd} ==="
    time ${clean_cmd}
}

function ctags_options() {
    
## also can Update the following snippet to ~/.ctags
#--langdef=Go
#--langmap=Go:.go
#--regex-Go=/func([ \t]+\([^)]+\))?[ \t]+([a-zA-Z0-9_]+)/\2/f,func/
#--regex-Go=/var[ \t]+([a-zA-Z_][a-zA-Z0-9_]+)/\1/v,var/
#--regex-Go=/type[ \t]+([a-zA-Z_][a-zA-Z0-9_]+)/\1/t,type/

#--langdef=Rust
#--langmap=Rust:.rs
#--regex-Rust=/^[ \t]*(#\[[^\]]\][ \t]*)*(pub[ \t]+)?(extern[ \t]+)?("[^"]+"[ \t]+)?(unsafe[ \t]+)?fn[ \t]+([a-zA-Z0-9_]+)/\6/f,functions,function definitions/
#--regex-Rust=/^[ \t]*(pub[ \t]+)?type[ \t]+([a-zA-Z0-9_]+)/\2/T,types,type definitions/
#--regex-Rust=/^[ \t]*(pub[ \t]+)?enum[ \t]+([a-zA-Z0-9_]+)/\2/g,enum,enumeration names/
#--regex-Rust=/^[ \t]*(pub[ \t]+)?struct[ \t]+([a-zA-Z0-9_]+)/\2/s,structure names/
#--regex-Rust=/^[ \t]*(pub[ \t]+)?mod[ \t]+([a-zA-Z0-9_]+)/\2/m,modules,module names/
#--regex-Rust=/^[ \t]*(pub[ \t]+)?(static|const)[ \t]+([a-zA-Z0-9_]+)/\3/c,consts,static constants/
#--regex-Rust=/^[ \t]*(pub[ \t]+)?trait[ \t]+([a-zA-Z0-9_]+)/\2/t,traits,traits/
#--regex-Rust=/^[ \t]*(pub[ \t]+)?impl([ \t\n]*<[^>]*>)?[ \t]+(([a-zA-Z0-9_:]+)[ \t]*(<[^>]*>)?[ \t]+(for)[ \t]+)?([a-zA-Z0-9_]+)/\4 \6 \7/i,impls,trait implementations/
#--regex-Rust=/^[ \t]*macro_rules![ \t]+([a-zA-Z0-9_]+)/\1/d,macros,macro definitions/

    local ctags_opt='
\n--langdef=Go
\n--langmap=Go:.go
\n--regex-Go=/func([ \\t]+\([^)]+\))?[ \\t]+([a-zA-Z0-9_]+)/\2/f,func/
\n--regex-Go=/var[ \\t]+([a-zA-Z_][a-zA-Z0-9_]+)/\1/v,var/
\n--regex-Go=/type[ \\t]+([a-zA-Z_][a-zA-Z0-9_]+)/\1/t,type/
\n--langdef=Rust
\n--langmap=Rust:.rs
\n--regex-Rust=/^[ \\t]*(#\[[^\]]\][ \\t]*)*(pub[ \\t]+)?(extern[ \\t]+)?("[^"]+"[ \\t]+)?(unsafe[ \\t]+)?fn[ \\t]+([a-zA-Z0-9_]+)/\6/f,functions,function definitions/
\n--regex-Rust=/^[ \\t]*(pub[ \\t]+)?type[ \\t]+([a-zA-Z0-9_]+)/\2/T,types,type definitions/
\n--regex-Rust=/^[ \\t]*(pub[ \\t]+)?enum[ \\t]+([a-zA-Z0-9_]+)/\2/g,enum,enumeration names/
\n--regex-Rust=/^[ \\t]*(pub[ \\t]+)?struct[ \\t]+([a-zA-Z0-9_]+)/\2/s,structure names/
\n--regex-Rust=/^[ \\t]*(pub[ \\t]+)?mod[ \\t]+([a-zA-Z0-9_]+)/\2/m,modules,module names/
\n--regex-Rust=/^[ \\t]*(pub[ \\t]+)?(static|const)[ \\t]+([a-zA-Z0-9_]+)/\3/c,consts,static constants/
\n--regex-Rust=/^[ \\t]*(pub[ \\t]+)?trait[ \\t]+([a-zA-Z0-9_]+)/\2/t,traits,traits/
\n--regex-Rust=/^[ \\t]*(pub[ \\t]+)?impl([ \\t\\n]*<[^>]*>)?[ \\t]+(([a-zA-Z0-9_:]+)[ \\t]*(<[^>]*>)?[ \\t]+(for)[ \\t]+)?([a-zA-Z0-9_]+)/\4 \6 \7/i,impls,trait implementations/
\n--regex-Rust=/^[ \\t]*macro_rules![ \\t]+([a-zA-Z0-9_]+)/\1/d,macros,macro definitions/
'
    echo -e ${ctags_opt} > ${CTAGS_OPTIONS}
}


function chk_gopath() { ## go project must under '${GOPATH}/src'

    local go_ok=1

    local go_src="${CUR_PATH##*/}"
    local go_path="${CUR_PATH%/*}"
    while [[ ${go_src} != "" ]]
    do
        if [[ ${go_src} == "src" ]]; then
            break
        fi

        go_src="${go_path##*/}"
        go_path="${go_path%/*}"
    done

    ## whether GO_PATH already set to GO ENV
    local go_env_path=false
    local go_env_paths=(${GOPATH//:/ })
    for gopath in ${go_env_paths[@]}
    do
        if [[ ${gopath} == ${go_path} ]]; then
            go_env_path=true
            break
        fi
    done

    if [[ ${go_src} != "src" ]]; then
        echo " '${CUR_PATH}' is not under a 'src' dir"

        go_ok=0
    else
        if [[ ${go_env_path} == false ]]; then
            echo " '${go_path}' not in 'GOPATH:${GOPATH}'"
            echo " try 'export GOPATH=${GOPATH}:${go_path}'"
            go_ok=0
        fi 
    fi

    return ${go_ok}
}


main (){
    if [[ $# == 1 && $1 == "clean" ]]; then
        clean_tags
        exit
    fi

    if [[ $# == 1 && $1 == "go" ]]; then
        chk_gopath 
        if [[ $? == 0 ]]; then
            exit
        fi
    fi

    make_tags "${DIRS[*]}" "${FILES[*]}"
}

main $1

