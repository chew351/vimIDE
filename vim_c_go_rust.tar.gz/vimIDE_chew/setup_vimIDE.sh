#!/bin/bash
# File              : setup_vimIDE.sh
# Author            : zcy
# Date              : 2019-03-04 18:09:48
# Last Modified Date: 2019-05-21 11:20:29

if [[ $1 == "install" ]]; then

    echo "=== Start install ... ==="

    ## apt-get update source
    echo " apt-get update ..."
    apt-get update > /dev/null
    if [[ $? != 0 ]]; then
        echo " apt-get update failed"
        exit
    fi

    ## install ctags cscope for source code tags
    echo " apt-get install -y ctags cscope ..."
    apt-get install -y ctags cscope > /dev/null
    if [[ $? != 0 ]]; then
        echo " apt-get install ctags cscope failed"
        exit
    fi

    ## install cowsay fortune for ssh login welcome 
    ## sudo add-apt-repository ppa:ytvwld/asciiquarium
    ## sudo apt-get update && sudo apt-get install asciiquarium
    echo " apt-get install -y cowsay fortune lolcat ..."
    apt-get install -y cowsay fortune lolcat > /dev/null
    if [[ $? != 0 ]]; then
        echo " apt-get install cowsay fortune lolcat failed"
        exit
    fi

    ## backup .vim and .vimrc
    if [[ -d "~/.vim" ]]; then
        echo " backup ~/.vim to ~/.vim_bak ..."
        mv ~/.vim ~/.vim_bak
    fi

    if [[ -f "~/.vimrc" ]]; then
        echo " backup ~/.vimrc to ~/.vimrc_bak ..."
        mv ~/.vimrc ~/.vimrc_bak
    fi

    ## install vim plugin and vimrc conf
    echo " copy vim to ~/.vim ..."
    cp -R ./vim ~/.vim
    echo " copy vimrc to ~/.vimrc ..."
    cp ./vimrc ~/.vimrc

    echo " copy sshwelcome.sh to /etc/profile.d ..."
    cp ./sshwelcome.sh /etc/profile.d/

    echo " Completed install."
    echo "=== Have a good day ! ==="

elif [[ $1 == "uninstall" ]]; then

    echo "=== Start uninstall ... ==="

    ## remove ctags cscope for source code tags
    echo " apt-get remove -y ctags cscope ..."
    apt-get remove -y ctags cscope > /dev/null
    if [[ $? != 0 ]]; then
        echo " apt-get remove -y ctags cscope failed"
    fi

    ## remove cowsay fortune lolcat for ssh login welcome 
    echo " apt-get remove -y cowsay fortune lolcat ..."
    apt-get remove -y cowsay fortune lolcat > /dev/null
    if [[ $? != 0 ]]; then
        echo " apt-get remove -y cowsay fortune lolcat failed"
        exit
    fi

    ## recovert .vim and .vimrc
    if [[ -d "~/.vim_bak" ]]; then
        echo " recovert ~/.vim_bak to ~/.vim ..."
        mv -f ~/.vim_bak ~/.vim
    else
        echo " remove ~/.vim ..."
        rm -fr ~/.vim
    fi

    if [[ -f "~/.vimrc_bak" ]]; then
        echo " recovert ~/.vimrc_bak to ~/.vimrc ..."
        mv -f ~/.vimrc_bak ~/.vimrc
    else
        echo " remove ~/.vimrc ..."
        rm -f ~/.vimrc
    fi

    echo " remove sshwelcome.sh from /etc/profile.d ..."
    rm -f /etc/profile.d/sshwelcome.sh

    echo " Completed uninstall."
    echo "=== Congratulateion!! ==="

else
    echo "Usage:"
    echo "    $0 <install | uninstall>"
fi

