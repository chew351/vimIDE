#!/bin/bash
# File              : sshwelcome.sh
# Author            : zcy
# Date              : 2019-03-05 09:46:52
# Last Modified Date: 2019-03-05 09:47:04

# call cowsay after login
ANIMAL=`/usr/games/cowsay -l | awk '{if (NR > 1){print }}' | awk '{for(i = 1; i < NF+1; i++) print $i}' | shuf -n 1`

echo "${ANIMAL}" say:
# pass sentence to cowsay with random animal
fortune | cowsay -f ${ANIMAL} | lolcat

